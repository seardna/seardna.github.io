<?php
/*
Template Name:No sidebar
*/
?>
<?php get_header(); $options = get_monochrome_option(); ?>

<div id="left_col">

 <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

 <div class="page_contents">
  <div class="post">
   <h2 class="post_title"><?php the_title(); ?></h2>
   <div class="post_content cf">
    <?php the_content(__('Read more', 'monochrome')); ?>
    <?php wp_link_pages(); ?>
   </div>
  </div>
 </div><!-- END post odd,even -->

<?php endwhile; else: ?>

 <div class="post_odd cf" id="no_post">
  <div class="post">
   <div class="post_content">
    <p><?php _e("Sorry, but you are looking for something that isn't here.","monochrome"); ?></p>
   </div>
  </div>
  <div class="post_meta">
  </div>
 </div>

 <?php endif; ?>

 <?php if ($options['show_comment']): ?>
 <div id="comments_wrapper">
  <?php if (function_exists('wp_list_comments')) { comments_template('', true); } else { comments_template(); } ?>
 </div>
 <?php endif; ?>

</div><!-- #left_col end -->

<?php get_footer(); ?>