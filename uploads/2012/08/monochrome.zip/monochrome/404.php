<?php get_header(); $options = get_monochrome_option(); ?>

<div id="left_col">

<div class="post_wrap cf">
 <div class="post_odd cf" id="no_post">
  <div class="post">
   <div class="post_content">
    <p><?php _e("Sorry, but you are looking for something that isn't here.","monochrome"); ?></p>
   </div>
  </div>
  <div class="post_meta">
  </div>
 </div>
</div>

<?php if ($options['pager'] == 'pager') { ?>
<?php include('navigation.php'); ?>
<?php } else { ?>
<div id="prev_next_post" class="cf">
 <p class="next_post"><?php next_posts_link( __( 'Older posts', 'monochrome' ) ); ?></p>
 <p class="prev_post"><?php previous_posts_link( __( 'Newer posts', 'monochrome' ) ); ?></p>
</div>
<?php }; ?>

</div><!-- #left_col end -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>