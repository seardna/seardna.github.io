</div><!-- END contents -->

<?php $options = get_monochrome_option(); ?>
<div id="footer">
 <ul id="copyright" class="cf">
  <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php bloginfo('name'); ?></a></li>
  <li><a href="http://www.mono-lab.net/" class="target_blank"><?php _e('Theme designed by mono-lab','monochrome'); ?></a></li>
  <li class="last"><a href="http://wordpress.org/" class="target_blank"><?php _e('Powered by WordPress','monochrome'); ?></a></li>
 </ul>
 <?php if ($options['show_return_top']) : ?>
 <a href="#header" id="return_top"><?php _e('Return top','monochrome'); ?></a>
 <?php endif; ?>
</div><!-- END #footer -->

<?php wp_footer(); ?>
</body>
</html>