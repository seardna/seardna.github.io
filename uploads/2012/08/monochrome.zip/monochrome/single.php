<?php get_header(); $options = get_monochrome_option(); ?>

<div id="left_col">

 <?php if ($options['show_bread_crumb']): ?>
 <div id="header_meta">
  <ul id="bread_crumb" class="cf">
   <li id="bc_home"><a href="<?php echo esc_url(home_url('/')); ?>"><?php _e('HOME','monochrome'); ?></a></li>
   <li id="bc_cat"><?php the_category(' . '); ?></li>
   <li><?php the_title(); ?></li>
  </ul>
 </div>
 <?php endif; ?>

 <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

 <div class="post_odd">
  <div class="post">
   <h2 class="post_title"><?php the_title(); ?></h2>
   <div class="post_content cf">
    <?php the_content(__('Read more', 'monochrome')); ?>
    <?php wp_link_pages(); ?>
   </div>
  </div>
  <div class="post_meta">
   <dl>
    <?php if ($options['show_date']) : ?>
    <dt class="meta_date"><?php the_time('Y') ?></dt>
    <dd class="post_date"><?php the_time('m') ?><span>/<?php the_time('d') ?></span></dd>
    <?php endif; ?>
    <?php if ($options['show_author']) : ?>
    <dt><?php _e('POSTED BY','monochrome'); ?></dt>
    <dd><?php the_author_posts_link(); ?></dd>
    <?php endif; ?>
    <?php if ($options['show_category']) : ?>
    <dt><?php _e('CATEGORY','monochrome'); ?></dt>
    <dd><?php the_category('<br />'); ?></dd>
    <?php endif; ?>
    <?php if ($options['show_tag']) : ?>
    <?php the_tags(__('<dt>TAGS</dt><dd>','monochrome'),'<br />','</dd>'); ?>
    <?php endif; ?>
    <?php if ($options['show_comment']) : ?>
    <dt class="meta_comment"><?php comments_popup_link(__('Write comment', 'monochrome'), __('1 comment', 'monochrome'), __('% comments', 'monochrome')); ?></dt>
    <?php endif; ?>
    <?php edit_post_link(__('[ EDIT ]', 'monochrome'), '<dd>', '</dd>' ); ?>
   </dl>
  </div><!-- END post_meta -->
 </div><!-- END post odd,even -->

<?php endwhile; else: ?>

 <div class="post_odd cf" id="no_post">
  <div class="post">
   <div class="post_content">
    <p><?php _e("Sorry, but you are looking for something that isn't here.","monochrome"); ?></p>
   </div>
  </div>
  <div class="post_meta">
  </div>
 </div>

 <?php endif; ?>

 <?php if ($options['show_comment']): ?>
 <div id="comments_wrapper">
  <?php if (function_exists('wp_list_comments')) { comments_template('', true); } else { comments_template(); } ?>
 </div>
 <?php endif; ?>

 <?php if ($options['show_next_post']) : ?>
 <div id="prev_next_post" class="cf">
  <?php next_post_link( '<p class="prev_post">%link</p>' ); ?>
  <?php previous_post_link( '<p class="next_post">%link</p>' ); ?>
 </div>
 <?php endif; ?>

</div><!-- #left_col end -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>