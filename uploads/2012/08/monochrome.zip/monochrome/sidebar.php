<?php $options = get_monochrome_option(); ?>

<div id="right_col">

 <?php if ($options['information_contents']) : ?>
 <div class="side_box" id="info_box">
  <h3 id="info_title"><?php echo ($options['information_title']); ?></h3>
  <?php echo wpautop($options['information_contents']); ?>
 </div>
 <?php endif; ?>

 <?php if($options['show_search'] || $options['show_rss'] || $options['twitter_url'] || $options['facebook_url']) { ?>
 <div class="side_box cf" id="side_meta_content">

  <?php if($options['show_rss'] || $options['twitter_url'] || $options['facebook_url']) { ?>
  <ul id="social_link" class="cf">
   <?php if ($options['show_rss']) : ?>
   <li class="rss_button"><a class="target_blank" href="<?php bloginfo('rss2_url'); ?>">rss</a></li>
   <?php endif; ?>
   <?php if ($options['twitter_url']) : ?>
   <li class="twitter_button"><a class="target_blank" href="<?php echo $options['twitter_url']; ?>">twitter</a></li>
   <?php endif; ?>
   <?php if ($options['facebook_url']) : ?>
   <li class="facebook_button"><a class="target_blank" href="<?php echo $options['facebook_url']; ?>">facebook</a></li>
   <?php endif; ?>
  </ul>
  <?php }; ?>

  <?php if ($options['show_search']) : ?>
  <div id="search_area">
   <?php if ($options['custom_search_id']) { ?>
   <form action="http://www.google.com/cse" method="get" id="searchform">
    <div>
     <input id="search_button" class="rollover" type="image" src="<?php bloginfo('template_url'); ?>/img/search_button.gif" name="sa" alt="<?php _e('SEARCH','monochrome'); ?>" title="<?php _e('SEARCH','monochrome'); ?>" />
     <input type="hidden" name="cx" value="<?php echo $options['custom_search_id']; ?>" />
     <input type="hidden" name="ie" value="UTF-8" />
    </div>
    <div><input id="search_input" type="text" value="<?php _e('SEARCH','monochrome'); ?>" name="q" onfocus="if (this.value == '<?php _e('SEARCH','monochrome'); ?>') this.value = '';" onblur="if (this.value == '') this.value = '<?php _e('SEARCH','monochrome'); ?>';" /></div>
   </form>
   <?php } else { ?>
   <form method="get" id="searchform" action="<?php echo esc_url(home_url('/')); ?>">
    <div><input id="search_button" class="rollover" type="image" src="<?php bloginfo('template_url'); ?>/img/search_button.gif" alt="<?php _e('SEARCH','monochrome'); ?>" title="<?php _e('SEARCH','monochrome'); ?>" /></div>
    <div><input id="search_input" type="text" value="<?php _e('SEARCH','monochrome'); ?>" name="s" onfocus="if (this.value == '<?php _e('SEARCH','monochrome'); ?>') this.value = '';" onblur="if (this.value == '') this.value = '<?php _e('SEARCH','monochrome'); ?>';" /></div>
   </form>
   <?php }; ?>
  </div>
  <?php endif; ?>

 </div>
 <?php }; // END #side_meta_content ?>

<?php if(is_active_sidebar('side_widget')){ dynamic_sidebar('side_widget'); } else { ?>

 <div class="side_box">
  <h3 class="side_title">Recent Post</h3>
  <ul>
   <?php $myposts = get_posts('numberposts=5'); foreach($myposts as $post) : ?>
   <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
   <?php endforeach; ?>
  </ul>
 </div>

 <div class="side_box">
  <h3 class="side_title">Calendar</h3>
  <?php get_calendar(true); ?>
 </div>

 <div class="side_box">
  <h3 class="side_title">Archives</h3>
  <ul>
   <?php wp_get_archives('type=monthly'); ?>
  </ul>
 </div>

 <div class="side_box">
  <h3 class="side_title">Category</h3>
  <ul>
   <?php wp_list_categories('title_li='); ?>
  </ul>
 </div>

<?php }; ?>

</div>