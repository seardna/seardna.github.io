----------------------------------------------------------------------------
  Release notes for monochrome
----------------------------------------------------------------------------

  Version:3.3

  Live demo
  http://www.mono-lab.net/demo1/

  Plese send me your language file!
  mail@mono-lab.net



----------------------------------------------------------------------------
  Change log
----------------------------------------------------------------------------

  ver3.3    2012/01/01  Add new function. (disable comment function)
  ver3.2.5  2011/08/22  Fixed comment template tag.
  ver3.2.4  2011/06/22  Add Slovak language file (Thank you Ja'n. http://www.janofoto.net)
  ver3.2.3  2010/11/02  Update Chinese languate file. (Thank you ���x�߉J.)
  ver3.2.2  2010/08/01  Add Falsi languate file. (Thank you Mahdi.)
  ver3.2    2010/08/01  Add Italian languate file. (Thank you Luca.)
  ver3.1    2010/06/28  Fixed old template tag 
  ver3.0.4  2010/06/06  Fixed page navigation.
  ver3.0.3  2010/06/01  Add new function.
  ver3.0    2010/04/16  Add new function.Fix style sheet and javascript error.
  ver2.6    2009/12/27  Add German language file. (Thank you Uli.)
  ver2.5    2009/12/20  Add Turkish language file. (Thank you Huseyin. http://gokekin.com)
  ver2.4    2009/12/07  Add Traditional Chinese language file. (Thank you Morgan.)
  ver2.3    2009/11/02  Add [EDIT] link in page-noside.php and page-noside-nocomment.php
  ver2.2    2009/09/21  Add Korean language file. (Thank you Jong-In. http://incommunity.codex.kr)
                        Add Spanish language file. (Thank you Ignacio. http://www.germanyague.com)
                        Add Dutch language file. (Thank you Niels. http://ritme.levendebrief.nl)
  ver2.1    2009/09/07  Add Catalan language file. (Thank you Marc. http://nuvolsgratis.cat/)
  ver2.0    2009/09/05  Add [ Exclude Pages and Categories form Header menu ] function.
                        Change format of copyright date (Thank you Jan. )
                        Fixed style.css ( hover color for even post )
                        Added Russian language file. (Thank you x-demon. http://x-demon.org/)
  ver1.7    2009/09/02  Added Brazilian portuguese language file. (Thank you Vinicius. http://vinicius.soylocoporti.org.br/)
                        Added Polish language file. (Thank you Karol.)
  ver1.6    2009/08/12  Added Chinese language file. (Thank you joojen. http://www.keege.com/)
  ver1.5    2009/08/02  Added Ukrainian language file. (Thank you Sasha.)
  ver1.4    2009/07/29  Fixed comment date.Plese replace "functions.php" and "comment.php" with new one. (Thank you chichi.)
  ver1.3    2009/07/26  Added French language file. (Thank you Reaves. http://www.catsjumping.com )
  ver1.2    2009/07/25  Added Danish language file. (Thank you Georg. http://wordpress.blogos.dk/ )
  ver1.1    2009/07/23  fixed page-nocomment.php,page-nocomment-noinfo.php,page-noside.php,page-noside-nocomment.php



----------------------------------------------------------------------------
   License
----------------------------------------------------------------------------

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.

